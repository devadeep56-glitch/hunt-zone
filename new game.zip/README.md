# HUNT ZONE — mobile-ready public web app

HUNT ZONE is a responsive, installable Progressive Web App (PWA) backed by Node.js, Express and Socket.IO. It includes live rooms, 5-character invite codes, up to 20 players, host controls, ready checks, randomized teams and a synchronized 20-minute timer.

## What is included

- Phone-first responsive layout, large touch targets and safe-area spacing
- PWA manifest, app icons, service worker and an install button where supported
- HTTPS-ready deployment behind a hosting provider's reverse proxy
- Socket.IO WebSocket transport with polling fallback; HTTPS pages automatically use secure WebSockets (`wss://`)
- `/health` endpoint for deployment health checks
- Basic security headers and optional Socket.IO origin allow-list
- Render deployment blueprint (`render.yaml`)

The service worker caches the app shell so the interface can load after a previous visit. Multiplayer actions still require an internet connection and the live server.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm start
```

Open `http://localhost:3000`. For phone testing on the same Wi-Fi, open `http://YOUR_COMPUTER_LAN_IP:3000` on the phone. The computer firewall must allow inbound TCP port 3000. Local HTTP is fine for testing; PWA installation and the service worker require HTTPS (except localhost).

## Publish publicly with Render (recommended beginner route)

1. Create a GitHub account if you do not already have one.
2. Create a new GitHub repository named `hunt-zone`.
3. Upload the contents of this project folder to the repository root. Make sure `package.json`, `render.yaml`, `server/`, and `public/` are at the top level.
4. In Render, choose **New + → Blueprint** and connect the GitHub repository.
5. Render reads `render.yaml`. Confirm the service is a **Web Service** and deploy it.
6. Wait for the deploy to finish. Render provides an HTTPS address such as `https://hunt-zone-xxxx.onrender.com` (your exact address will differ).
7. Open that HTTPS address on two phones/devices. Create a room on one, join with the code on the other, ready both players and start the match.
8. On supported mobile browsers, use the **INSTALL APP** prompt or the browser menu's **Add to Home Screen** option.

**Important:** the included Render blueprint uses the paid `starter` plan. This is intentional for a live multiplayer game: free services may sleep, interrupt active matches or have cold starts. The app keeps rooms in server memory, so a server restart/deploy clears every active room.

### Custom domain

In Render's service settings, add your domain, then follow the DNS records Render displays at your domain registrar. Render provisions and renews TLS certificates after DNS verification. Use the final `https://` domain for players. Do not terminate TLS yourself inside this Node app; the platform handles HTTPS and forwards traffic to the app. Socket.IO then negotiates `wss://` automatically from the secure page.

### Optional origin restriction

By default, the app accepts its same-origin Socket.IO connections. If you need to restrict connections to specific website origins, set `ALLOWED_ORIGIN` to a comma-separated list of exact origins, for example:

```text
ALLOWED_ORIGIN=https://your-domain.example,https://www.your-domain.example
```

Do not include paths or trailing slashes in origin values. Leave it unset for the default same-origin deployment.

## Other hosts

Railway, Fly.io or another Node.js host can also run this project if it supports a persistent web process, HTTPS termination and WebSocket upgrades. Set:

- Build command: `npm install`
- Start command: `npm start`
- Node version: `20` or newer
- Health check: `/health` (if supported)

The app listens on `0.0.0.0` and uses the `PORT` environment variable supplied by the host. Do not deploy to static-only hosting such as a plain static site bucket: the Node.js/Socket.IO server is required.

## Current game scope and production limits

This is a multiplayer lobby and team-assignment foundation, not yet a complete GPS game. It does **not** implement live GPS sharing, a map radar, scanning or capture mechanics. The app explicitly disables geolocation permission in its browser Permissions-Policy until a separate privacy- and safety-reviewed feature is added.

Rooms and reconnect sessions are held in memory in one Node process. A restart clears them. Do not run multiple instances unless you add shared persistence and a Socket.IO adapter such as Redis. Before a large public launch, add stronger abuse controls, moderation/reporting, persistent storage, monitoring and load testing.

For real-world play, keep activities in public, permitted areas. No roads, trespassing, unsafe chasing or physical contact. Players should be able to stop at any time.

## Verify before deploying

```bash
npm run check
npm start
```

In another terminal, test `http://localhost:3000/health`. It should return JSON with `ok: true`. After deployment, test `https://YOUR_PUBLIC_HOST/health` and run a two-device multiplayer test.
