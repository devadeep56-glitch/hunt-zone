const crypto = require("node:crypto");

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const MAX_PLAYERS = 20;
const RECONNECT_GRACE_MS = 60_000;
const ROOM_EMPTY_TTL_MS = 5 * 60_000;

function makeId() {
  return crypto.randomBytes(18).toString("base64url");
}

function cleanName(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 18);
}

function cleanCode(value) {
  return String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5);
}

function randomCode() {
  let result = "";
  const bytes = crypto.randomBytes(5);
  for (const byte of bytes) result += CODE_ALPHABET[byte % CODE_ALPHABET.length];
  return result;
}

function shuffle(items) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = crypto.randomInt(i + 1);
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

class RoomManager {
  constructor(io) {
    this.io = io;
    this.rooms = new Map();
    this.playerRoom = new Map();
    this.disconnectTimers = new Map();
    this.cleanupTimers = new Map();
  }

  createRoom(name, socketId, resumeToken) {
    const playerName = cleanName(name);
    if (!playerName) throw new Error("Enter a player name first.");
    let code;
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const candidate = randomCode();
      if (!this.rooms.has(candidate)) { code = candidate; break; }
    }
    if (!code) throw new Error("Couldn't generate a room code. Please try again.");

    const room = {
      code,
      hostId: null,
      players: new Map(),
      status: "lobby",
      settings: { maxPlayers: MAX_PLAYERS },
      createdAt: Date.now(),
      startedAt: null,
      endsAt: null,
      teams: null
    };
    this.rooms.set(code, room);
    const player = this.addPlayer(room, playerName, socketId, null, true);
    room.hostId = player.id;
    return { room, player };
  }

  joinRoom(codeInput, name, socketId, resumeToken) {
    const code = cleanCode(codeInput);
    if (code.length !== 5) throw new Error("Room codes must contain 5 characters.");
    const room = this.rooms.get(code);
    if (!room) throw new Error("Room not found. Check the code and try again.");
    if (room.status !== "lobby") throw new Error("This match has already started.");
    const playerName = cleanName(name);
    if (!playerName) throw new Error("Enter a player name first.");
    if (room.players.size >= room.settings.maxPlayers) throw new Error("This room is full (20/20).");
    const duplicate = [...room.players.values()].some(p => p.name.toLowerCase() === playerName.toLowerCase() && p.connected);
    if (duplicate) throw new Error("That player name is already being used in this room.");
    const player = this.addPlayer(room, playerName, socketId, null, false);
    this.broadcastRoom(room);
    return { room, player };
  }

  addPlayer(room, name, socketId, resumeToken, isHost) {
    const id = makeId();
    const token = resumeToken || makeId();
    const player = {
      id, token, name, socketId, isHost,
      ready: false, connected: true, team: null,
      joinedAt: Date.now(), lastSeen: Date.now()
    };
    room.players.set(id, player);
    this.playerRoom.set(id, room.code);
    this.cancelDisconnect(token);
    return player;
  }

  findPlayerBySocket(socketId) {
    for (const room of this.rooms.values()) {
      for (const player of room.players.values()) {
        if (player.socketId === socketId) return { room, player };
      }
    }
    return null;
  }

  resume(socketId, token) {
    if (!token) return null;
    for (const room of this.rooms.values()) {
      for (const player of room.players.values()) {
        if (player.token === token) {
          if (room.status === "finished") return null;
          this.cancelDisconnect(token);
          player.socketId = socketId;
          player.connected = true;
          player.lastSeen = Date.now();
          this.io.sockets.sockets.get(socketId)?.join(room.code);
          this.broadcastRoom(room);
          this.emitSnapshot(socketId, room, player);
          return { room, player };
        }
      }
    }
    return null;
  }

  setReady(socketId, ready) {
    const found = this.findPlayerBySocket(socketId);
    if (!found) throw new Error("You are not in a room.");
    const { room, player } = found;
    if (room.status !== "lobby") throw new Error("The match has already started.");
    player.ready = Boolean(ready);
    this.broadcastRoom(room);
  }

  removePlayer(socketId, targetId) {
    const found = this.findPlayerBySocket(socketId);
    if (!found) throw new Error("You are not in a room.");
    const { room, player: actor } = found;
    if (actor.id !== room.hostId) throw new Error("Only the host can remove players.");
    if (room.status !== "lobby") throw new Error("Players cannot be removed after the match starts.");
    if (targetId === room.hostId) throw new Error("The host cannot remove themselves.");
    const target = room.players.get(targetId);
    if (!target) throw new Error("That player is no longer in the room.");
    room.players.delete(targetId);
    this.playerRoom.delete(targetId);
    if (target.socketId) {
      this.io.to(target.socketId).emit("room:removed", { message: "The host removed you from the lobby." });
      this.io.sockets.sockets.get(target.socketId)?.leave(room.code);
    }
    this.cancelDisconnect(target.token);
    this.broadcastRoom(room);
  }

  startMatch(socketId) {
    const found = this.findPlayerBySocket(socketId);
    if (!found) throw new Error("You are not in a room.");
    const { room, player } = found;
    if (player.id !== room.hostId) throw new Error("Only the host can start the match.");
    if (room.status !== "lobby") throw new Error("The match has already started.");
    if (room.players.size < 2) throw new Error("At least 2 players are required.");
    const players = [...room.players.values()];
    const notReady = players.filter(p => !p.ready || !p.connected);
    if (notReady.length) throw new Error("Everyone must be online and ready before starting.");
    const shuffled = shuffle(players);
    const copsCount = Math.max(1, Math.floor(shuffled.length / 2));
    room.teams = {};
    shuffled.forEach((p, index) => {
      p.team = index < copsCount ? "cop" : "burglar";
      room.teams[p.id] = p.team;
    });
    room.status = "running";
    room.startedAt = Date.now();
    room.endsAt = room.startedAt + 20 * 60_000;
    this.broadcastRoom(room);
    this.io.to(room.code).emit("match:started", {
      startedAt: room.startedAt,
      endsAt: room.endsAt,
      durationMs: 20 * 60_000,
      teams: room.teams
    });
  }

  disconnect(socketId) {
    const found = this.findPlayerBySocket(socketId);
    if (!found) return;
    const { room, player } = found;
    player.connected = false;
    player.socketId = null;
    player.lastSeen = Date.now();
    this.broadcastRoom(room);
    const timer = setTimeout(() => {
      const currentRoom = this.rooms.get(room.code);
      const currentPlayer = currentRoom?.players.get(player.id);
      if (!currentPlayer || currentPlayer.connected) return;
      currentRoom.players.delete(player.id);
      this.playerRoom.delete(player.id);
      this.disconnectTimers.delete(player.token);
      if (currentRoom.hostId === player.id) {
        const nextHost = [...currentRoom.players.values()].find(p => p.connected);
        if (nextHost) {
          currentRoom.hostId = nextHost.id;
          nextHost.isHost = true;
        }
      }
      if (currentRoom.players.size === 0) this.scheduleRoomCleanup(currentRoom.code);
      else this.broadcastRoom(currentRoom);
    }, RECONNECT_GRACE_MS);
    this.disconnectTimers.set(player.token, timer);
  }

  leave(socketId) {
    const found = this.findPlayerBySocket(socketId);
    if (!found) return;
    const { room, player } = found;
    room.players.delete(player.id);
    this.playerRoom.delete(player.id);
    this.cancelDisconnect(player.token);
    if (room.hostId === player.id) {
      const nextHost = [...room.players.values()].find(p => p.connected);
      if (nextHost) {
        room.hostId = nextHost.id;
        nextHost.isHost = true;
      }
    }
    if (room.players.size === 0) this.scheduleRoomCleanup(room.code);
    else this.broadcastRoom(room);
  }

  scheduleRoomCleanup(code) {
    if (this.cleanupTimers.has(code)) clearTimeout(this.cleanupTimers.get(code));
    const timer = setTimeout(() => {
      const room = this.rooms.get(code);
      if (room && [...room.players.values()].every(p => !p.connected)) this.deleteRoom(code);
    }, ROOM_EMPTY_TTL_MS);
    this.cleanupTimers.set(code, timer);
  }

  deleteRoom(code) {
    const room = this.rooms.get(code);
    if (!room) return;
    for (const player of room.players.values()) {
      this.playerRoom.delete(player.id);
      this.cancelDisconnect(player.token);
    }
    this.rooms.delete(code);
    const cleanup = this.cleanupTimers.get(code);
    if (cleanup) clearTimeout(cleanup);
    this.cleanupTimers.delete(code);
  }

  cancelDisconnect(token) {
    const timer = this.disconnectTimers.get(token);
    if (timer) clearTimeout(timer);
    this.disconnectTimers.delete(token);
  }

  snapshot(room, viewer) {
    return {
      code: room.code,
      status: room.status,
      hostId: room.hostId,
      maxPlayers: room.settings.maxPlayers,
      playerCount: room.players.size,
      players: [...room.players.values()].map(p => ({
        id: p.id,
        name: p.name,
        ready: p.ready,
        connected: p.connected,
        isHost: p.id === room.hostId,
        isYou: p.id === viewer.id,
        team: room.status === "lobby" ? null : p.team
      })),
      canStart: viewer.id === room.hostId &&
        room.status === "lobby" &&
        room.players.size >= 2 &&
        [...room.players.values()].every(p => p.ready && p.connected),
      startedAt: room.startedAt,
      endsAt: room.endsAt,
      yourTeam: viewer.team
    };
  }

  emitSnapshot(socketId, room, player) {
    this.io.to(socketId).emit("room:state", this.snapshot(room, player));
  }

  broadcastRoom(room) {
    for (const player of room.players.values()) {
      if (player.connected && player.socketId) this.emitSnapshot(player.socketId, room, player);
    }
  }

  getPublicStats() {
    return { activeRooms: this.rooms.size, maxPlayersPerRoom: MAX_PLAYERS };
  }
}

module.exports = { RoomManager, cleanCode, cleanName, MAX_PLAYERS };
