const path = require("node:path");
const http = require("node:http");
const express = require("express");
const { Server } = require("socket.io");
const { RoomManager, cleanCode } = require("./roomManager");

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1); // HTTPS is terminated by the hosting provider's reverse proxy.
app.use((_req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("X-Frame-Options", "DENY");
  next();
});

const server = http.createServer(app);
const allowedOrigins = (process.env.ALLOWED_ORIGIN || "").split(",").map(v => v.trim()).filter(Boolean);
const socketOptions = {
  transports: ["websocket", "polling"],
  pingInterval: 25_000,
  pingTimeout: 20_000,
  maxHttpBufferSize: 16_384,
  allowRequest: (req, callback) => {
    const origin = req.headers.origin;
    if (!origin) return callback(null, true);
    if (allowedOrigins.length) return callback(null, allowedOrigins.includes(origin));
    try {
      const parsed = new URL(origin);
      const forwardedHost = req.headers["x-forwarded-host"];
      const expectedHost = (Array.isArray(forwardedHost) ? forwardedHost[0] : forwardedHost) || req.headers.host;
      const forwardedProto = req.headers["x-forwarded-proto"];
      const expectedProto = (Array.isArray(forwardedProto) ? forwardedProto[0] : forwardedProto) || (req.socket.encrypted ? "https" : "http");
      callback(null, parsed.host === expectedHost && parsed.protocol === `${expectedProto}:`);
    } catch { callback(null, false); }
  }
};
if (allowedOrigins.length) socketOptions.cors = { origin: allowedOrigins, methods: ["GET", "POST"] };
const io = new Server(server, socketOptions);
const rooms = new RoomManager(io);

app.use(express.static(path.join(__dirname, "..", "public"), {
  etag: true,
  maxAge: process.env.NODE_ENV === "production" ? "1h" : 0
}));
app.get("/health", (_req, res) => res.json({ ok: true, service: "hunt-zone", ...rooms.getPublicStats() }));

function ackError(ack, error) {
  if (typeof ack === "function") ack({ ok: false, error: error.message || "Something went wrong." });
}

io.on("connection", socket => {
  socket.on("session:resume", (payload = {}, ack) => {
    try {
      const result = rooms.resume(socket.id, String(payload.token || ""));
      if (!result) return typeof ack === "function" && ack({ ok: true, resumed: false });
      socket.join(result.room.code);
      if (typeof ack === "function") ack({ ok: true, resumed: true, token: result.player.token });
    } catch (error) { ackError(ack, error); }
  });

  socket.on("room:create", (payload = {}, ack) => {
    try {
      const result = rooms.createRoom(payload.name, socket.id, payload.token);
      socket.join(result.room.code);
      rooms.broadcastRoom(result.room);
      if (typeof ack === "function") ack({ ok: true, code: result.room.code, token: result.player.token });
    } catch (error) { ackError(ack, error); }
  });

  socket.on("room:join", (payload = {}, ack) => {
    try {
      const result = rooms.joinRoom(cleanCode(payload.code), payload.name, socket.id, payload.token);
      socket.join(result.room.code);
      rooms.broadcastRoom(result.room);
      if (typeof ack === "function") ack({ ok: true, code: result.room.code, token: result.player.token });
    } catch (error) { ackError(ack, error); }
  });

  socket.on("player:ready", (payload = {}, ack) => {
    try { rooms.setReady(socket.id, payload.ready); if (typeof ack === "function") ack({ ok: true }); }
    catch (error) { ackError(ack, error); }
  });
  socket.on("host:remove-player", (payload = {}, ack) => {
    try { rooms.removePlayer(socket.id, String(payload.playerId || "")); if (typeof ack === "function") ack({ ok: true }); }
    catch (error) { ackError(ack, error); }
  });
  socket.on("match:start", (_payload = {}, ack) => {
    try { rooms.startMatch(socket.id); if (typeof ack === "function") ack({ ok: true }); }
    catch (error) { ackError(ack, error); }
  });
  socket.on("room:leave", (_payload = {}, ack) => {
    try {
      const found = rooms.findPlayerBySocket(socket.id);
      if (found) socket.leave(found.room.code);
      rooms.leave(socket.id);
      if (typeof ack === "function") ack({ ok: true });
    } catch (error) { ackError(ack, error); }
  });
  socket.on("disconnect", () => rooms.disconnect(socket.id));
});

const PORT = Number(process.env.PORT) || 3000;
server.listen(PORT, "0.0.0.0", () => console.log(`HUNT ZONE listening on port ${PORT}`));

for (const signal of ["SIGTERM", "SIGINT"]) {
  process.on(signal, () => server.close(() => process.exit(0)));
}
