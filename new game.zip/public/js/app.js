(() => {
  "use strict";
  const socket = io({ transports: ["websocket", "polling"], reconnection: true, reconnectionAttempts: Infinity });
  const $ = id => document.getElementById(id);
  const views = ["homeView", "lobbyView", "matchView"];
  let roomState = null;
  let sessionToken = sessionStorage.getItem("hz_session_token") || "";
  let activeCode = "";
  let toastTimer = null;
  let clockTimer = null;

  // Install prompt is shown only when the browser says the PWA can be installed.
  let installPrompt = null;
  const installButton = $("installButton");
  window.addEventListener("beforeinstallprompt", event => {
    event.preventDefault();
    installPrompt = event;
    installButton.classList.remove("hidden");
  });
  installButton.addEventListener("click", async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null;
    installButton.classList.add("hidden");
  });
  window.addEventListener("appinstalled", () => {
    installPrompt = null;
    installButton.classList.add("hidden");
    toast("HUNT ZONE installed on your device.");
  });
  if ("serviceWorker" in navigator && location.protocol === "https:") {
    window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
  }

  function toast(message) {
    const node = $("toast");
    node.textContent = message;
    node.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.classList.remove("show"), 3200);
  }
  function showView(id) {
    views.forEach(view => $(view).classList.toggle("hidden", view !== id));
  }
  function setConnection(connected) {
    $("connectionDot").style.background = connected ? "var(--green)" : "var(--red)";
    $("connectionDot").style.boxShadow = connected ? "0 0 10px var(--green)" : "0 0 10px var(--red)";
    $("connectionText").textContent = connected ? "SERVER ONLINE" : "RECONNECTING";
    $("connectionText").parentElement.classList.toggle("offline", !connected);
  }
  function emitAck(event, payload) {
    return new Promise((resolve, reject) => {
      if (!socket.connected) return reject(new Error("Not connected to the game server. Check your internet and try again."));
      socket.timeout(7000).emit(event, payload, (err, response) => {
        if (err) return reject(new Error("The server took too long to respond. Please try again."));
        if (!response?.ok) return reject(new Error(response?.error || "Request failed."));
        resolve(response);
      });
    });
  }
  function saveToken(token) {
    if (token) {
      sessionToken = token;
      sessionStorage.setItem("hz_session_token", token);
    }
  }
  function clearSession() {
    sessionToken = "";
    sessionStorage.removeItem("hz_session_token");
    roomState = null;
    activeCode = "";
    if (clockTimer) clearInterval(clockTimer);
  }
  function initials(name) {
    return name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
  }
  function renderPlayers(players, target, isMatch = false) {
    target.innerHTML = "";
    players.forEach(player => {
      const card = document.createElement("div");
      card.className = isMatch ? "match-player" : "player-card";
      if (isMatch) {
        const name = document.createElement("span");
        name.textContent = player.name + (player.isYou ? " (YOU)" : "");
        const team = document.createElement("span");
        team.className = "team-chip " + (player.team === "burglar" ? "burglar" : "");
        team.textContent = player.team ? player.team.toUpperCase() : "—";
        card.append(name, team);
      } else {
        const avatar = document.createElement("div");
        avatar.className = "avatar";
        avatar.textContent = initials(player.name);
        const info = document.createElement("div");
        info.className = "player-info";
        const name = document.createElement("b");
        name.textContent = player.name;
        if (player.isHost) {
          const host = document.createElement("span");
          host.className = "host-tag";
          host.textContent = "HOST";
          name.append(host);
        }
        if (player.isYou) {
          const you = document.createElement("small");
          you.textContent = "YOU";
          you.style.marginLeft = "7px";
          name.append(you);
        }
        const detail = document.createElement("small");
        detail.textContent = player.connected ? (player.ready ? "Ready for deployment" : "In the lobby") : "Reconnecting…";
        info.append(name, detail);
        const state = document.createElement("span");
        state.className = "player-state" + (!player.connected ? " offline" : "");
        state.textContent = !player.connected ? "OFFLINE" : player.ready ? "READY" : "ONLINE";
        card.append(avatar, info, state);
        if (roomState?.players?.some(p => p.isYou && p.isHost) && !player.isYou && roomState.status === "lobby") {
          const remove = document.createElement("button");
          remove.className = "remove-btn";
          remove.type = "button";
          remove.title = `Remove ${player.name}`;
          remove.setAttribute("aria-label", `Remove ${player.name}`);
          remove.textContent = "×";
          remove.addEventListener("click", async () => {
            if (!confirm(`Remove ${player.name} from this lobby?`)) return;
            try { await emitAck("host:remove-player", { playerId: player.id }); }
            catch (error) { toast(error.message); }
          });
          card.append(remove);
        }
      }
      target.append(card);
    });
  }
  function renderState(state) {
    roomState = state;
    activeCode = state.code;
    $("displayCode").textContent = state.code;
    $("playerCount").textContent = `${state.playerCount}/${state.maxPlayers}`;
    renderPlayers(state.players, $("playerList"));
    const me = state.players.find(player => player.isYou);
    const readyCard = $("myStatus");
    readyCard.classList.toggle("ready", Boolean(me?.ready));
    readyCard.querySelector("b").textContent = me?.ready ? "READY" : "NOT READY";
    readyCard.querySelector("small").textContent = me?.connected ? "Your signal is active" : "Reconnecting…";
    $("readyButton").textContent = me?.ready ? "✕ I'M NOT READY" : "✓ I'M READY";
    $("readyButton").classList.toggle("is-ready", Boolean(me?.ready));
    const isHost = Boolean(me?.isHost);
    $("hostControls").classList.toggle("hidden", !isHost || state.status !== "lobby");
    $("guestWaiting").classList.toggle("hidden", isHost || state.status !== "lobby");
    $("startButton").disabled = !state.canStart;
    $("startHint").textContent = state.playerCount < 2 ? "Need at least 2 players." :
      state.players.some(p => !p.connected) ? "Waiting for offline players to reconnect." :
      state.players.some(p => !p.ready) ? "Waiting for everyone to get ready." : "All clear. Launch when ready.";
    if (state.status === "running") showMatch(state);
    else showView("lobbyView");
  }
  function showMatch(state) {
    showView("matchView");
    $("matchCode").textContent = `ROOM ${state.code}`;
    const me = state.players.find(p => p.isYou);
    const team = me?.team || state.yourTeam || "cop";
    $("teamLabel").textContent = team === "cop" ? "COP" : "BURGLAR";
    $("teamLabel").classList.toggle("burglar", team === "burglar");
    $("teamDescription").textContent = team === "cop"
      ? "Protect the zone. Coordinate with your squad and play fair."
      : "Stay sharp. Work with your squad and play fair.";
    $("matchPlayerCount").textContent = `${state.playerCount} OPERATORS`;
    renderPlayers(state.players, $("matchPlayerList"), true);
    startClock(state.endsAt);
  }
  function startClock(endsAt) {
    if (clockTimer) clearInterval(clockTimer);
    const update = () => {
      const remaining = Math.max(0, endsAt - Date.now());
      const seconds = Math.ceil(remaining / 1000);
      $("matchTimer").textContent = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
      $("timerBar").style.width = `${Math.max(0, remaining / (20 * 60_000) * 100)}%`;
      if (remaining <= 0) {
        $("teamDescription").textContent = "Time is up. The operation has ended.";
        clearInterval(clockTimer);
      }
    };
    update();
    clockTimer = setInterval(update, 250);
  }

  $("createForm").addEventListener("submit", async event => {
    event.preventDefault();
    const button = event.currentTarget.querySelector("button");
    button.disabled = true;
    try {
      const result = await emitAck("room:create", { name: $("hostName").value, token: sessionToken });
      saveToken(result.token);
      toast(`Room ${result.code} created. You're the host!`);
    } catch (error) { toast(error.message); }
    finally { button.disabled = false; }
  });

  $("joinForm").addEventListener("submit", async event => {
    event.preventDefault();
    const button = event.currentTarget.querySelector("button");
    button.disabled = true;
    try {
      const result = await emitAck("room:join", {
        name: $("joinName").value,
        code: $("roomCode").value.trim().toUpperCase(),
        token: sessionToken
      });
      saveToken(result.token);
      toast(`Joined room ${result.code}. Welcome aboard!`);
    } catch (error) { toast(error.message); }
    finally { button.disabled = false; }
  });

  $("roomCode").addEventListener("input", event => {
    event.target.value = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5);
  });

  $("copyButton").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(activeCode);
      toast("Room code copied. Send it to your squad!");
    } catch {
      toast(`Your room code is ${activeCode}`);
    }
  });

  $("readyButton").addEventListener("click", async () => {
    const me = roomState?.players.find(p => p.isYou);
    try { await emitAck("player:ready", { ready: !me?.ready }); }
    catch (error) { toast(error.message); }
  });

  $("startButton").addEventListener("click", async () => {
    try { await emitAck("match:start", {}); }
    catch (error) { toast(error.message); }
  });

  $("leaveButton").addEventListener("click", async () => {
    try { await emitAck("room:leave", {}); } catch (error) { toast(error.message); }
    clearSession();
    showView("homeView");
  });

  $("returnButton").addEventListener("click", async () => {
    try { await emitAck("room:leave", {}); } catch {}
    clearSession();
    showView("homeView");
  });

  socket.on("connect", async () => {
    setConnection(true);
    if (sessionToken) {
      try {
        const result = await emitAck("session:resume", { token: sessionToken });
        if (!result.resumed) clearSession();
      } catch (error) { toast(error.message); }
    }
  });
  socket.on("disconnect", () => setConnection(false));
  socket.on("connect_error", () => setConnection(false));
  socket.on("room:state", renderState);
  socket.on("room:removed", payload => {
    clearSession();
    showView("homeView");
    toast(payload?.message || "You were removed from the room.");
  });
  socket.on("match:started", payload => {
    if (roomState) {
      roomState.status = "running";
      roomState.startedAt = payload.startedAt;
      roomState.endsAt = payload.endsAt;
      roomState.players = roomState.players.map(p => ({ ...p, team: payload.teams[p.id] || null }));
      renderState(roomState);
    }
    toast("Operation started. Good luck!");
  });
  socket.on("room:error", payload => toast(payload?.message || "Room error."));
  setConnection(socket.connected);
})();
